#include <gtk/gtk.h>
#include "bin.h"

typedef struct
{
    GtkWidget *w_dlg_file_choose;
    GtkWidget *w_image_main;
}app_widgets;

int main(int argc, char *argv[])
{
    GtkBuilder *builder;
    GtkWidget  *window;

    app_widgets     *widgets = g_slice_new(app_widgets);

    gtk_init(&argc, &argv);

    builder = gtk_builder_new_from_file("new.glade");

    window = GTK_WIDGET(gtk_builder_get_object(builder,"window_main"));

    widgets->w_dlg_file_choose = GTK_WIDGET(gtk_builder_get_object(builder,"dlg_file_choose"));
    widgets->w_image_main = GTK_WIDGET(gtk_builder_get_object(builder,"img_main"));
    
    gtk_builder_connect_signals(builder,widgets);

    g_object_unref(builder);

    gtk_widget_show_all(window);
    gtk_main();

    g_slice_free(app_widgets,widgets);

    return 0;

}


//Fonction permettant d'ouvrir un fichier avec le bouton Open
void on_menuitm_open_activate(GtkMenuItem *menuitem, app_widgets *app_wdgts)
{
    gchar *filename = NULL;

    gtk_widget_show(app_wdgts->w_dlg_file_choose); 

    if(gtk_dialog_run(GTK_DIALOG(app_wdgts->w_dlg_file_choose)) == GTK_RESPONSE_OK)
    {
        filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(app_wdgts->w_dlg_file_choose));
        
        int len = 0;
        int i = 0;

        while(filename[i])
        {
            len++;
            i++;
        }
        if(((filename[len-1] == 'g')&&(filename[len-2] == 'p')&&(filename[len-3] == 'j'))||((filename[len-1] == 'p')&&(filename[len-2] == 'm')&&(filename[len-3] == 'b')))
        {
            //Charge le nom du fichier dans mon pointeur
            gtk_image_set_from_file(GTK_IMAGE(app_wdgts->w_image_main),filename);
            //L'appel de l'OCR devrait se faire ici. 
        }
        else
        {
            GtkBuilder *builder; 
            builder = gtk_builder_new_from_file("new.glade");
            GtkWidget *pop_up;
            pop_up = GTK_WIDGET(gtk_builder_get_object(builder,"pop_up"));
            gtk_widget_show_all(pop_up);
        }
        g_free(filename);
    }
    gtk_widget_hide(app_wdgts->w_dlg_file_choose);
}
//Permet de fermer mon explorateur de fichier
void on_menuitm_close_activate(GtkMenuItem *menuitem, app_widgets *app_wdgts)
{
    gtk_main_quit();
}

//Fonction se rapportant à l'utilisation de la fenêtre à propos
void on_a_propos_activate(GtkMenuItem *menuitem, app_widgets *app_wdgts)
{
    GtkBuilder *builder; 
    builder = gtk_builder_new_from_file("new.glade");
    GtkWidget *a_propos;
    a_propos = GTK_WIDGET(gtk_builder_get_object(builder,"a_propos_window"));
    gtk_widget_show_all(a_propos);

}

//Permet de fermet ma fenêtre principale
void on_window_main_destroy()
{
    gtk_main_quit();
}





